#!/bin/bash

export LD_LIBRARY_PATH=./libs:LD_LIBRARY_PATH
./earthworms
